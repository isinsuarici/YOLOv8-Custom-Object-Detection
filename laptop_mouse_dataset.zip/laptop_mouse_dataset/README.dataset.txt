# Laptop and Mouse > 2023-03-18 8:26am
https://universe.roboflow.com/estu-qjt4d/laptop-and-mouse

Provided by a Roboflow user
License: CC BY 4.0

